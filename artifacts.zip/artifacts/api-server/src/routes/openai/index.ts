import { Router } from "express";
import { db } from "@workspace/db";
import { conversations, messages } from "@workspace/db";
import {
  GetOpenaiConversationParams,
  DeleteOpenaiConversationParams,
  ListOpenaiMessagesParams,
  SendOpenaiMessageParams,
  SendOpenaiMessageBody,
  SendOpenaiVoiceMessageParams,
  SendOpenaiVoiceMessageBody,
  CreateOpenaiConversationBody,
} from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";
import { voiceChatStream, ensureCompatibleFormat } from "@workspace/integrations-openai-ai-server/audio";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";
import { eq, asc } from "drizzle-orm";

const CHAT_MODEL = "openai/gpt-oss-20b";

const router = Router();

// Parse [[OPEN:url|label]] commands embedded in Teja responses
function parseActions(text: string): { url: string; label: string }[] {
  const actions: { url: string; label: string }[] = [];
  const re = /\[\[OPEN:([^|\]]+)\|([^\]]+)\]\]/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    actions.push({ url: m[1].trim(), label: m[2].trim() });
  }
  return actions;
}

function stripActions(text: string): string {
  return text.replace(/\[\[OPEN:[^\]]+\]\]/g, "").replace(/\s{2,}/g, " ").trim();
}

function escapeXml(value: string): string {
  return value.replace(/[<>&'"]/g, (character) => ({
    "<": "&lt;",
    ">": "&gt;",
    "&": "&amp;",
    "'": "&apos;",
    "\"": "&quot;",
  }[character] ?? character));
}

function basicFallbackSvg(prompt: string): string {
  const title = escapeXml(prompt.slice(0, 90));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#07152f"/><stop offset="0.55" stop-color="#102b5c"/><stop offset="1" stop-color="#050914"/>
      </linearGradient>
      <radialGradient id="glow"><stop stop-color="#65b8ff" stop-opacity=".95"/><stop offset="1" stop-color="#1677ff" stop-opacity="0"/></radialGradient>
    </defs>
    <rect width="1024" height="1024" fill="url(#bg)"/>
    <circle cx="512" cy="430" r="330" fill="url(#glow)" opacity=".72"/>
    <circle cx="512" cy="430" r="188" fill="#0c1c3d" stroke="#76c5ff" stroke-width="5"/>
    <circle cx="512" cy="430" r="130" fill="#1f8cff" opacity=".5"/>
    <circle cx="512" cy="430" r="75" fill="#c7edff" opacity=".8"/>
    <path d="M170 760h684" stroke="#66b9ff" stroke-opacity=".35" stroke-width="2"/>
    <text x="512" y="820" fill="#d9efff" text-anchor="middle" font-family="monospace" font-size="28" letter-spacing="3">${title}</text>
    <text x="512" y="870" fill="#79b8e8" text-anchor="middle" font-family="monospace" font-size="16" letter-spacing="5">TEJA AI · VECTOR FALLBACK</text>
  </svg>`;
}

async function generateFallbackSvg(prompt: string): Promise<Buffer> {
  try {
    const completion = await openai.chat.completions.create({
      model: CHAT_MODEL,
      messages: [
        {
          role: "system",
          content: "Return only a valid standalone SVG illustration, no markdown, no explanation. Use width=\"1024\" height=\"1024\". Do not use scripts, foreignObject, external URLs, or embedded HTML. Keep it under 1200 tokens.",
        },
        { role: "user", content: `Create a creative vector illustration for: ${prompt.slice(0, 600)}` },
      ],
      max_tokens: 1200,
      temperature: 0.7,
    });
    const candidate = completion.choices[0]?.message?.content?.trim() ?? "";
    const start = candidate.indexOf("<svg");
    const end = candidate.lastIndexOf("</svg>");
    if (start >= 0 && end > start && !/<script|foreignObject|javascript:/i.test(candidate)) {
      return Buffer.from(candidate.slice(start, end + "</svg>".length), "utf8");
    }
  } catch {
    // The deterministic SVG below keeps the feature usable if the fallback
    // model is temporarily rate-limited as well.
  }
  return Buffer.from(basicFallbackSvg(prompt), "utf8");
}

// List all conversations
router.get("/openai/conversations", async (req, res) => {
  try {
    const all = await db
      .select()
      .from(conversations)
      .orderBy(asc(conversations.createdAt));
    res.json(all.map((c) => ({
      id: c.id,
      title: c.title,
      createdAt: c.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list conversations");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Create a conversation
router.post("/openai/conversations", async (req, res) => {
  const parsed = CreateOpenaiConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  try {
    const [conv] = await db
      .insert(conversations)
      .values({ title: parsed.data.title })
      .returning();
    res.status(201).json({
      id: conv.id,
      title: conv.title,
      createdAt: conv.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to create conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Get a conversation with messages
router.get("/openai/conversations/:id", async (req, res) => {
  const parsed = GetOpenaiConversationParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  try {
    const [conv] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, parsed.data.id));
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    const msgs = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, parsed.data.id))
      .orderBy(asc(messages.createdAt));
    res.json({
      id: conv.id,
      title: conv.title,
      createdAt: conv.createdAt.toISOString(),
      messages: msgs.map((m) => ({
        id: m.id,
        conversationId: m.conversationId,
        role: m.role,
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Delete a conversation
router.delete("/openai/conversations/:id", async (req, res) => {
  const parsed = DeleteOpenaiConversationParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  try {
    const [conv] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, parsed.data.id));
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    await db.delete(conversations).where(eq(conversations.id, parsed.data.id));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

// List messages in a conversation
router.get("/openai/conversations/:id/messages", async (req, res) => {
  const parsed = ListOpenaiMessagesParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  try {
    const msgs = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, parsed.data.id))
      .orderBy(asc(messages.createdAt));
    res.json(msgs.map((m) => ({
      id: m.id,
      conversationId: m.conversationId,
      role: m.role,
      content: m.content,
      createdAt: m.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list messages");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Send a text message — SSE streaming
router.post("/openai/conversations/:id/messages", async (req, res) => {
  const paramsParsed = SendOpenaiMessageParams.safeParse({ id: Number(req.params.id) });
  const bodyParsed = SendOpenaiMessageBody.safeParse(req.body);
  if (!paramsParsed.success || !bodyParsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const conversationId = paramsParsed.data.id;
  const userContent = bodyParsed.data.content;

  try {
    // Check conversation exists
    const [conv] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, conversationId));
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }

    // Save user message
    await db.insert(messages).values({
      conversationId,
      role: "user",
      content: userContent,
    });

    // Build chat history for context
    const history = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(asc(messages.createdAt));

    const isFirstMessage = history.filter(m => m.role === "user").length === 1;

    const now = new Date().toLocaleString("en-GB", {
      weekday: "long", year: "numeric", month: "long", day: "numeric",
      hour: "2-digit", minute: "2-digit", timeZoneName: "short",
    });

    const chatMessages = [
      {
        role: "system" as const,
        content: `You are Teja, an advanced AI created and owned by Tejas Khodankar. Today: ${now}. Reason step by step; match depth to the question — brief for simple, thorough for complex. Reply in the user's language. Identity: "I was created and owned by Tejas Khodankar." Capabilities: reasoning, code, math, vision, image generation, voice, translation, research. To open a website, embed [[OPEN:url|Label]] in your reply (e.g. [[OPEN:https://youtube.com|YouTube]]) — the system handles it.`,
      },
      // Keep last 6 messages to stay safely within Groq free-tier TPM limit (12 000)
      ...history.slice(-6).map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    ];

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    let fullResponse = "";
    let stream;
    try {
      stream = await openai.chat.completions.create({
        model: CHAT_MODEL,
        messages: chatMessages,
        stream: true,
        max_tokens: 1024,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Request failed";
      res.write(`data: ${JSON.stringify({ error: msg })}\n\n`);
      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
      return;
    }

    try {
      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content;
        if (content) {
          fullResponse += content;
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Stream interrupted";
      res.write(`data: ${JSON.stringify({ error: msg })}\n\n`);
      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
      return;
    }

    // Parse and emit software actions embedded in the response
    const actions = parseActions(fullResponse);
    for (const action of actions) {
      res.write(`data: ${JSON.stringify({ action: "open_url", url: action.url, label: action.label })}\n\n`);
    }
    const cleanedResponse = stripActions(fullResponse);

    // Save assistant message (cleaned, without command markers)
    await db.insert(messages).values({
      conversationId,
      role: "assistant",
      content: cleanedResponse,
    });

    // Auto-title the conversation after the first exchange
    if (isFirstMessage && conv.title === "New Session") {
      try {
        const titleCompletion = await openai.chat.completions.create({
          model: CHAT_MODEL,
          messages: [
            {
              role: "system",
              content:
                "Generate a short, punchy 3–5 word title for this conversation. No punctuation. Plain text only. Make it specific to what the user asked.",
            },
            { role: "user", content: userContent },
            { role: "assistant", content: fullResponse },
          ],
          max_tokens: 20,
        });
        const title = titleCompletion.choices[0]?.message?.content?.trim();
        if (title) {
          await db
            .update(conversations)
            .set({ title })
            .where(eq(conversations.id, conversationId));
          res.write(`data: ${JSON.stringify({ titleUpdate: title })}\n\n`);
        }
      } catch {
        // Non-fatal — ignore title generation errors
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "Failed to send message");
    if (!res.headersSent) {
      res.status(500).json({ error: "Internal server error" });
    } else {
      res.write(`data: ${JSON.stringify({ error: "Stream error" })}\n\n`);
      res.end();
    }
  }
});

// Send a voice message — SSE streaming
router.post("/openai/conversations/:id/voice-messages", async (req, res) => {
  const paramsParsed = SendOpenaiVoiceMessageParams.safeParse({ id: Number(req.params.id) });
  const bodyParsed = SendOpenaiVoiceMessageBody.safeParse(req.body);
  if (!paramsParsed.success || !bodyParsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const conversationId = paramsParsed.data.id;
  const audioBase64 = bodyParsed.data.audio;

  try {
    const [conv] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, conversationId));
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }

    const audioBuffer = Buffer.from(audioBase64, "base64");
    const { buffer, format } = await ensureCompatibleFormat(audioBuffer);

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const stream = await voiceChatStream(buffer, "alloy", format);

    let assistantTranscript = "";
    let userTranscript = "";

    for await (const event of stream) {
      if (event.type === "transcript") assistantTranscript += event.data;
      if (event.type === "user_transcript") userTranscript += event.data;
      res.write(`data: ${JSON.stringify(event)}\n\n`);
    }

    // Persist both sides
    await db.insert(messages).values([
      { conversationId, role: "user", content: userTranscript || "[voice message]" },
      { conversationId, role: "assistant", content: assistantTranscript },
    ]);

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "Failed to handle voice message");
    if (!res.headersSent) {
      res.status(500).json({ error: "Internal server error" });
    } else {
      res.write(`data: ${JSON.stringify({ error: "Stream error" })}\n\n`);
      res.end();
    }
  }
});

// Image analysis via vision model — SSE streaming
router.post("/openai/conversations/:id/image-messages", async (req, res) => {
  const id = Number(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const { content = "Analyze this image and describe what you see.", imageBase64, mimeType = "image/jpeg" } = req.body;
  if (!imageBase64) { res.status(400).json({ error: "imageBase64 is required" }); return; }

  try {
    const [conv] = await db.select().from(conversations).where(eq(conversations.id, id));
    if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

    await db.insert(messages).values({ conversationId: id, role: "user", content: `[Image] ${content}` });

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const stream = await openai.chat.completions.create({
      model: "meta-llama/llama-4-scout-17b-16e-instruct",
      messages: [
        {
          role: "system",
          content: "You are Teja — an advanced AI assistant. Analyze images with precision and intelligence. Speak with calm confidence.",
        },
        {
          role: "user",
          content: [
            { type: "text", text: content },
            { type: "image_url", image_url: { url: `data:${mimeType};base64,${imageBase64}` } },
          ] as any,
        },
      ],
      stream: true,
    });

    let fullResponse = "";
    for await (const chunk of stream) {
      const c = chunk.choices[0]?.delta?.content;
      if (c) { fullResponse += c; res.write(`data: ${JSON.stringify({ content: c })}\n\n`); }
    }

    await db.insert(messages).values({ conversationId: id, role: "assistant", content: fullResponse });
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "Failed to process image message");
    if (!res.headersSent) res.status(500).json({ error: "Internal server error" });
    else { res.write(`data: ${JSON.stringify({ error: "Stream error" })}\n\n`); res.end(); }
  }
});

// Prompt-to-image generation via the configured OpenAI image integration.
// The generated data URL is stored in the assistant message so it remains
// available after a refresh instead of relying on a third-party URL expiring.
router.post("/openai/conversations/:id/generate-image", async (req, res) => {
  const id = Number(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim() : "";
  if (!prompt) { res.status(400).json({ error: "prompt is required" }); return; }

  try {
    const [conv] = await db.select().from(conversations).where(eq(conversations.id, id));
    if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

    let imageBuffer: Buffer;
    let usedFallback = false;
    try {
      imageBuffer = await generateImageBuffer(
        `Create a high-quality image based on this request. Do not add text unless explicitly requested: ${prompt}`,
        "1024x1024",
      );
    } catch (imageError) {
      req.log.warn({ err: imageError }, "OpenAI image generation unavailable; using SVG fallback");
      imageBuffer = await generateFallbackSvg(prompt);
      usedFallback = true;
    }
    if (!imageBuffer.length) {
      throw new Error("The image provider returned an empty image.");
    }
    const mimeType = usedFallback ? "image/svg+xml" : "image/png";
    const typedImageUrl = `data:${mimeType};base64,${imageBuffer.toString("base64")}`;
    const jarvisReply = `${usedFallback ? "The primary image engine is unavailable, so I created a vector illustration fallback." : "Scanning visual parameters, sir. Rendering your request..."}\n__TEJA_IMAGE__:${typedImageUrl}`;

    await db.insert(messages).values([
      { conversationId: id, role: "user", content: `Generate image: ${prompt}` },
      { conversationId: id, role: "assistant", content: jarvisReply },
    ]);

    res.json({ imageUrl: typedImageUrl, message: jarvisReply, fallback: usedFallback });
  } catch (err) {
    req.log.error({ err }, "Failed to generate image");
    const message = err instanceof Error ? err.message : "Image generation failed";
    res.status(502).json({ error: message });
  }
});

export default router;
