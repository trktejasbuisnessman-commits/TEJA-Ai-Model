import { useEffect, useRef } from "react";
import { ClerkProvider, Show, useClerk, AuthenticateWithRedirectCallback } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { dark } from "@clerk/themes";
import { Switch, Route, useLocation, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import Patent from "@/pages/Patent";
import SignInPage from "@/pages/SignIn";
import SignUpPage from "@/pages/SignUp";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } },
});

// ── Clerk config ──────────────────────────────────────────────
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

// ── Appearance ────────────────────────────────────────────────
const clerkAppearance = {
  baseTheme: dark,
  cssLayerName: "clerk" as const,
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    socialButtonsPlacement: "top" as const,
    socialButtonsVariant: "blockButton" as const,
  },
  variables: {
    colorPrimary: "hsl(210 100% 60%)",
    colorForeground: "hsl(210 40% 92%)",
    colorMutedForeground: "hsl(210 20% 55%)",
    colorDanger: "hsl(0 85% 60%)",
    colorBackground: "hsl(222 47% 7%)",
    colorInput: "hsl(222 30% 12%)",
    colorInputForeground: "hsl(210 40% 90%)",
    colorNeutral: "hsl(210 20% 30%)",
    fontFamily: "'Inter', monospace",
    borderRadius: "0.75rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "rounded-2xl w-[440px] max-w-full overflow-hidden shadow-[0_0_80px_hsl(210_100%_60%/0.12),0_32px_64px_rgba(0,0,0,0.6)]",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-blue-200 font-mono tracking-widest uppercase text-lg",
    headerSubtitle: "text-blue-400/60 font-mono text-xs tracking-wider",
    socialButtonsBlockButtonText: "text-blue-200 font-mono text-sm tracking-wider",
    formFieldLabel: "text-blue-300/70 font-mono text-xs tracking-wider uppercase",
    footerActionLink: "text-blue-400 hover:text-blue-300 font-mono text-xs",
    footerActionText: "text-blue-400/40 font-mono text-xs",
    dividerText: "text-blue-400/30 font-mono text-xs tracking-widest uppercase",
    identityPreviewEditButton: "text-blue-400",
    formFieldSuccessText: "text-green-400/80 font-mono text-xs",
    alertText: "text-red-400/80 font-mono text-xs",
    logoBox: "flex justify-center mb-2",
    logoImage: "w-12 h-12",
    socialButtonsBlockButton: "border border-blue-400/25 hover:border-blue-400/50 hover:bg-blue-400/5 transition-all duration-200",
    formButtonPrimary: "bg-blue-500 hover:bg-blue-400 font-mono tracking-widest uppercase text-xs transition-all duration-200 shadow-[0_0_20px_hsl(210_100%_60%/0.3)]",
    formFieldInput: "font-mono text-sm border-blue-400/20 focus:border-blue-400/60 bg-transparent placeholder:text-blue-400/20",
    footerAction: "bg-transparent border-t border-blue-400/10",
    dividerLine: "bg-blue-400/15",
    alert: "border border-red-400/20 bg-red-400/5",
    otpCodeFieldInput: "border-blue-400/30 font-mono",
    formFieldRow: "",
    main: "",
  },
};

// ── Cache invalidator ─────────────────────────────────────────
function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsub = addListener(({ user }) => {
      const uid = user?.id ?? null;
      if (prevRef.current !== undefined && prevRef.current !== uid) qc.clear();
      prevRef.current = uid;
    });
    return unsub;
  }, [addListener, qc]);

  return null;
}

// ── Home route: always go straight to chat ───────────────────
function HomeRoute() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/chat" />
      </Show>
      <Show when="signed-out">
        <Redirect to="/chat" />
      </Show>
    </>
  );
}

// ── /chat — open to everyone ──────────────────────────────────
function ChatRoute() {
  return <Home />;
}

// ── /patent — open to everyone ────────────────────────────────
function PatentRoute() {
  return <Patent />;
}

// ── Router ────────────────────────────────────────────────────
function AppRouter() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey!}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: "Welcome back", subtitle: "Sign in to access Teja AI" } },
        signUp: { start: { title: "Create account", subtitle: "Get access to Teja AI" } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ClerkQueryClientCacheInvalidator />
          <Switch>
            <Route path="/" component={HomeRoute} />
            <Route path="/chat" component={ChatRoute} />
            <Route path="/sign-in/sso-callback" component={() => (
              <AuthenticateWithRedirectCallback
                signInForceRedirectUrl={`${basePath}/chat`}
                signUpForceRedirectUrl={`${basePath}/chat`}
              />
            )} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/sso-callback" component={() => (
              <AuthenticateWithRedirectCallback
                signInForceRedirectUrl={`${basePath}/chat`}
                signUpForceRedirectUrl={`${basePath}/chat`}
              />
            )} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            <Route path="/patent" component={PatentRoute} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <AppRouter />
    </WouterRouter>
  );
}

export default App;
