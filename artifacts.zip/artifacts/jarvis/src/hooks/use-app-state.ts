import { create } from "zustand";

interface AppState {
  activeConversationId: number | null;
  setActiveConversationId: (id: number | null) => void;
}

export const useAppState = create<AppState>((set) => ({
  activeConversationId: null,
  setActiveConversationId: (id) => set({ activeConversationId: id }),
}));
