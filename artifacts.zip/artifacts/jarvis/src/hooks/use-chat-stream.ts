import { useState, useRef, useCallback } from "react";
import { useAppState } from "./use-app-state";
import {
  useListOpenaiMessages,
  getListOpenaiMessagesQueryKey,
  getListOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useVoiceRecorder, useVoiceStream } from "@workspace/integrations-openai-ai-react";

export function useChatStream() {
  const { activeConversationId } = useAppState();
  const queryClient = useQueryClient();
  const [streamingContent, setStreamingContent] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [optimisticMessage, setOptimisticMessage] = useState<string | null>(null);
  const [lastAction, setLastAction] = useState<{ label: string; url: string } | null>(null);

  const { data: messages = [] } = useListOpenaiMessages(activeConversationId!, {
    query: {
      enabled: !!activeConversationId,
      queryKey: getListOpenaiMessagesQueryKey(activeConversationId!),
    },
  });

  const abortControllerRef = useRef<AbortController | null>(null);

  // Voice setup — hooks must be in same order every render
  const workletPath = import.meta.env.BASE_URL + "audio-playback-worklet.js";
  const { streamVoiceResponse, playbackState } = useVoiceStream({
    workletPath,
    onTranscript: (_, full) => setStreamingContent(full),
    onUserTranscript: (text) => setOptimisticMessage(text),
    onComplete: () => {
      queryClient.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(activeConversationId!) });
      setOptimisticMessage(null);
      setStreamingContent("");
      setIsStreaming(false);
    },
    onError: (err) => { console.error("Voice stream error", err); setIsStreaming(false); },
  });

  const { state: recordingState, startRecording, stopRecording } = useVoiceRecorder();

  // ── Helpers (plain functions, not hooks) ──────────────────
  const BASE = import.meta.env.BASE_URL;

  const invalidateMessages = () => {
    queryClient.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(activeConversationId!) });
  };

  const readSSEStream = async (response: Response) => {
    if (!response.body) throw new Error("The assistant returned an empty response stream.");
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let currentContent = "";
    let buffer = "";
    let streamHadError = false;

    const processEvent = (line: string) => {
      if (!line.startsWith("data: ")) return;
      try {
        const event = JSON.parse(line.slice(6));
        if (event.content) {
          currentContent += event.content;
          setStreamingContent(currentContent);
        }
        if (event.titleUpdate) {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
        }
        if (event.action === "open_url" && event.url) {
          window.open(event.url, "_blank", "noopener,noreferrer");
          setLastAction({ label: event.label ?? event.url, url: event.url });
          setTimeout(() => setLastAction(null), 5000);
        }
        if (event.error) {
          streamHadError = true;
          setStreamingContent(`⚠ ${event.error}`);
          setIsStreaming(false);
        }
        if (event.done) {
          invalidateMessages();
          setOptimisticMessage(null);
          if (!streamHadError && !currentContent.trim()) {
            setStreamingContent("⚠ The assistant returned an empty response. Please try again.");
          } else if (!streamHadError) {
            setStreamingContent("");
          }
          setIsStreaming(false);
        }
      } catch {
        // Ignore malformed keep-alive lines, but keep valid events visible.
      }
    };

    while (true) {
      const { done, value } = await reader.read();
      buffer += decoder.decode(value ?? new Uint8Array(), { stream: !done });
      const completeEvents = buffer.split(/\r?\n\r?\n/);
      buffer = completeEvents.pop() ?? "";
      for (const eventBlock of completeEvents) {
        for (const line of eventBlock.split(/\r?\n/)) processEvent(line);
      }
      if (done) break;
    }
    if (buffer.trim()) {
      for (const line of buffer.split(/\r?\n/)) processEvent(line);
    }
  };

  // ── Actions ───────────────────────────────────────────────
  const sendMessage = async (content: string) => {
    if (!activeConversationId) return;
    abortControllerRef.current?.abort();
    abortControllerRef.current = new AbortController();
    setOptimisticMessage(content);
    setIsStreaming(true);
    setStreamingContent("");
    try {
      const response = await fetch(`${BASE}api/openai/conversations/${activeConversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
        signal: abortControllerRef.current.signal,
      });
      if (!response.ok) {
        const details = await response.json().catch(() => null);
        throw new Error(details?.error || "Failed to send message");
      }
      await readSSEStream(response);
    } catch (error: any) {
      if (error.name !== "AbortError") {
        setStreamingContent(`⚠ ${error instanceof Error ? error.message : "Unable to reach the assistant."}`);
        setIsStreaming(false);
        setOptimisticMessage(null);
      }
      setIsStreaming(false);
    }
  };

  const sendImageMessage = async (imageBase64: string, mimeType: string, content: string) => {
    if (!activeConversationId) return;
    setOptimisticMessage(`[Image] ${content || "Analyze this image"}`);
    setIsStreaming(true);
    setStreamingContent("");
    try {
      const response = await fetch(`${BASE}api/openai/conversations/${activeConversationId}/image-messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: content || "Analyze this image and describe what you see.", imageBase64, mimeType }),
      });
      if (!response.ok) {
        const details = await response.json().catch(() => null);
        throw new Error(details?.error || "Failed to send image");
      }
      await readSSEStream(response);
    } catch (error: any) {
      console.error("Image stream error:", error);
      setStreamingContent("⚠ Vision analysis failed. Please try again.");
      setIsStreaming(false);
      await new Promise(r => setTimeout(r, 4000));
      setStreamingContent("");
      setOptimisticMessage(null);
    }
  };

  const generateImage = async (prompt: string) => {
    if (!activeConversationId) return;
    setOptimisticMessage(`Generate image: ${prompt}`);
    setIsStreaming(true);
    setStreamingContent("Rendering visual parameters...");
    try {
      const response = await fetch(`${BASE}api/openai/conversations/${activeConversationId}/generate-image`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!response.ok) {
        const details = await response.json().catch(() => null);
        throw new Error(details?.error || "Image generation failed");
      }
      const result = await response.json();
      if (!result?.imageUrl) throw new Error("Image provider returned no image");
      invalidateMessages();
      setOptimisticMessage(null);
      setStreamingContent("");
      setIsStreaming(false);
    } catch (error: any) {
      console.error("Image generation error:", error);
      setStreamingContent("⚠ Image generation failed. Please try again.");
      setIsStreaming(false);
      await new Promise(r => setTimeout(r, 4000));
      setStreamingContent("");
      setOptimisticMessage(null);
    }
  };

  const handleStartVoice = useCallback(async () => {
    if (!activeConversationId) return;
    await startRecording();
  }, [activeConversationId, startRecording]);

  const handleStopVoice = useCallback(async () => {
    if (!activeConversationId) return;
    const blob = await stopRecording();
    if (blob.size === 0) return;
    setOptimisticMessage("Audio input...");
    setIsStreaming(true);
    setStreamingContent("Listening...");
    try {
      await streamVoiceResponse(`${BASE}api/openai/conversations/${activeConversationId}/voice-messages`, blob);
    } catch (e) { console.error(e); setIsStreaming(false); }
  }, [activeConversationId, stopRecording, streamVoiceResponse, BASE]);

  return {
    messages,
    sendMessage,
    sendImageMessage,
    generateImage,
    streamingContent,
    isStreaming,
    optimisticMessage,
    lastAction,
    recordingState,
    playbackState,
    handleStartVoice,
    handleStopVoice,
  };
}
