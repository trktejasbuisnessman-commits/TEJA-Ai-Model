import { useEffect } from "react";
import { useAppState } from "./use-app-state";
import {
  useListOpenaiConversations,
  useCreateOpenaiConversation,
  useGetOpenaiConversation,
  useListOpenaiMessages,
  useDeleteOpenaiConversation,
  getListOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export function useConversations() {
  const queryClient = useQueryClient();
  const { activeConversationId, setActiveConversationId } = useAppState();

  const { data: conversations = [], isLoading: isLoadingConversations } =
    useListOpenaiConversations({
      query: { queryKey: getListOpenaiConversationsQueryKey() },
    });

  const createMutation = useCreateOpenaiConversation();
  const deleteMutation = useDeleteOpenaiConversation();

  useEffect(() => {
    if (!isLoadingConversations && conversations.length === 0 && !createMutation.isPending) {
      createMutation.mutate(
        { data: { title: "New Session" } },
        {
          onSuccess: (newConv) => {
            queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
            setActiveConversationId(newConv.id);
          },
        }
      );
    } else if (
      !isLoadingConversations &&
      conversations.length > 0 &&
      activeConversationId === null
    ) {
      setActiveConversationId(conversations[0].id);
    }
  }, [conversations, isLoadingConversations, activeConversationId, createMutation.isPending, queryClient, setActiveConversationId]);

  const createConversation = () => {
    createMutation.mutate(
      { data: { title: "New Session" } },
      {
        onSuccess: (newConv) => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          setActiveConversationId(newConv.id);
        },
      }
    );
  };

  const deleteConversation = (id: number) => {
    deleteMutation.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          if (activeConversationId === id) {
            setActiveConversationId(null);
          }
        },
      }
    );
  };

  return {
    conversations,
    activeConversationId,
    setActiveConversationId,
    createConversation,
    deleteConversation,
    isLoading: isLoadingConversations || createMutation.isPending,
  };
}
