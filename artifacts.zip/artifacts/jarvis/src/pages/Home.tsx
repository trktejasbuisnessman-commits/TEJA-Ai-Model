import React, { useEffect, useRef, useState } from "react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton,
  SidebarMenuItem, SidebarProvider,
} from "@/components/ui/sidebar";
import { Plus, Trash2, Mic, Square, Send, Zap, Cpu, Wifi, Paperclip, Wand2, X, ImageIcon, ExternalLink, Globe, Rocket, Award, LogOut, User, LogIn } from "lucide-react";
import { useLocation } from "wouter";
import { useClerk, useUser, useAuth } from "@clerk/react";
import { useConversations } from "@/hooks/use-conversations";
import { useChatStream } from "@/hooks/use-chat-stream";
import { Button } from "@/components/ui/button";

/* ── Orbital Reactor ─────────────────────────────────────── */
function ArcReactor({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const sm = size === "sm";
  const lg = size === "lg";
  const outer = lg ? "w-28 h-28" : sm ? "w-9 h-9" : "w-12 h-12";
  const coreSize = lg ? "w-8 h-8" : sm ? "w-2.5 h-2.5" : "w-3 h-3";
  return (
    <div className={`arc-reactor ${sm ? "arc-reactor-sm" : ""} ${outer} relative flex items-center justify-center`}>
      <div className="ring-outer" />
      <div className="ring-mid" />
      <div className="ring-inner" />
      {!sm && <div className="orbit-dot" />}
      {!sm && <div className="orbit-dot-2" />}
      <div className={`core ${coreSize}`} />
    </div>
  );
}

/* ── HUD Corners ─────────────────────────────────────────── */
function HudCorners() {
  return (
    <>
      <div className="hud-corner hud-corner-tl" />
      <div className="hud-corner hud-corner-tr" />
      <div className="hud-corner hud-corner-bl" />
      <div className="hud-corner hud-corner-br" />
    </>
  );
}

/* ── Waveform ────────────────────────────────────────────── */
function Waveform() {
  return (
    <div className="flex items-center gap-[3px] h-6">
      {[1, 2, 3, 4, 5].map(i => <div key={i} className="wave-bar" style={{ height: "4px" }} />)}
    </div>
  );
}

/* ── Thinking dots ───────────────────────────────────────── */
function Thinking() {
  return (
    <div className="flex items-center gap-2 px-4 py-3 msg-jarvis rounded-2xl w-fit max-w-[140px]">
      <div className="jarvis-thinking flex gap-1.5">
        <span /><span /><span />
      </div>
      <span className="text-[10px] font-mono text-primary/40 tracking-widest">REASONING</span>
    </div>
  );
}

/* ── Boot Sequence ───────────────────────────────────────── */
function BootSequence() {
  return (
    <div className="h-full flex flex-col items-center justify-center gap-10 select-none">
      <ArcReactor size="lg" />
      <div className="flex flex-col items-center gap-2 font-mono text-center">
        <h1 className="text-5xl font-bold tracking-[0.4em] jarvis-glow text-primary boot-line">
          TEJA
        </h1>
        <p className="text-xs text-primary/50 tracking-[0.35em] uppercase boot-line">
          Advanced Intelligence System
        </p>
        <div className="mt-8 flex flex-col gap-2 text-left text-xs text-primary/40 boot-line w-72">
          <div className="flex justify-between">
            <span>▶ Core intelligence</span>
            <span className="text-green-400/70">ONLINE</span>
          </div>
          <div className="telemetry-bar mt-1 mb-1" />
          <div className="flex justify-between">
            <span>▶ Reasoning engine</span>
            <span className="text-green-400/70">ACTIVE</span>
          </div>
          <div className="flex justify-between">
            <span>▶ Vision &amp; generation</span>
            <span className="text-green-400/70">READY</span>
          </div>
          <div className="flex justify-between">
            <span>▶ Software interface</span>
            <span className="text-green-400/70">LINKED</span>
          </div>
          <div className="telemetry-bar mt-1 mb-1" />
          <p className="text-primary/60 jarvis-glow-sm text-center tracking-widest">
            ▶ SYSTEMS NOMINAL — READY
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3 text-[10px] text-primary/30 font-mono tracking-[0.3em] uppercase boot-line border border-primary/10 px-4 py-2 rounded-full">
        <span className="status-dot" />
        All systems operational
        <Rocket className="w-3 h-3 ml-1" />
      </div>
    </div>
  );
}

/* ── Message Content Renderer ────────────────────────────── */
function MessageContent({ content }: { content: string }) {
  if (content.includes("__TEJA_IMAGE__:")) {
    const idx = content.indexOf("__TEJA_IMAGE__:");
    const text = content.slice(0, idx).trim();
    const url = content.slice(idx + "__TEJA_IMAGE__:".length).trim();
    return (
      <>
        {text && <div className="whitespace-pre-wrap mb-3">{text}</div>}
        <div className="relative group">
          <img
            src={url}
            alt="Teja AI rendered"
            className="rounded-xl max-w-full border border-primary/25 shadow-[0_0_32px_hsl(210_100%_65%/0.12)] transition-all duration-300 group-hover:shadow-[0_0_48px_hsl(210_100%_65%/0.22)]"
            style={{ maxHeight: "520px", objectFit: "contain" }}
            loading="lazy"
          />
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/70 text-primary/80 text-[10px] font-mono px-2 py-1 rounded border border-primary/20 backdrop-blur-sm"
          >
            OPEN ↗
          </a>
        </div>
      </>
    );
  }
  return <div className="whitespace-pre-wrap leading-relaxed">{content}</div>;
}

/* ── Capability Badge ────────────────────────────────────── */
function CapBadge({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-primary/15 bg-primary/5 text-[9px] font-mono text-primary/50 tracking-widest uppercase">
      {icon}
      {label}
    </div>
  );
}

/* ── Main ────────────────────────────────────────────────── */
export default function Home() {
  const [, navigate] = useLocation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const { isSignedIn } = useAuth();
  const {
    conversations, activeConversationId,
    setActiveConversationId, createConversation, deleteConversation,
  } = useConversations();

  const {
    messages, sendMessage, sendImageMessage, generateImage,
    streamingContent, isStreaming, optimisticMessage,
    lastAction, recordingState, handleStartVoice, handleStopVoice, playbackState,
  } = useChatStream();

  const [input, setInput] = useState("");
  const [mode, setMode] = useState<"chat" | "imagine">("chat");
  const [attachedImage, setAttachedImage] = useState<{ base64: string; mimeType: string; preview: string } | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, streamingContent, optimisticMessage]);

  const clearAttachment = () => {
    setAttachedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      const [header, base64] = dataUrl.split(",");
      const mimeType = header.match(/:(.*?);/)?.[1] ?? "image/jpeg";
      setAttachedImage({ base64, mimeType, preview: dataUrl });
      setMode("chat");
    };
    reader.readAsDataURL(file);
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isStreaming) return;

    if (mode === "imagine") {
      if (!input.trim()) return;
      const prompt = input.trim();
      setInput("");
      await generateImage(prompt);
      return;
    }

    if (attachedImage) {
      const text = input.trim();
      const img = attachedImage;
      setInput("");
      clearAttachment();
      await sendImageMessage(img.base64, img.mimeType, text);
      return;
    }

    if (!input.trim()) return;
    sendMessage(input.trim());
    setInput("");
    inputRef.current?.focus();
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      onSubmit(e as unknown as React.FormEvent);
    }
  };

  const isIdle = !messages.length && !optimisticMessage && !isStreaming;

  const placeholder = mode === "imagine"
    ? "Describe what you want to create..."
    : attachedImage
      ? "Ask Teja about this image... (or just send)"
      : "Ask anything — Teja thinks in first principles...";

  return (
    <SidebarProvider defaultOpen>
      <div className="jarvis-bg" />
      <div className="jarvis-scanlines" />

      <div className="flex h-screen w-full overflow-hidden text-foreground relative z-10">

        {/* ══ SIDEBAR ═════════════════════════════════════ */}
        <Sidebar className="border-r border-sidebar-border bg-sidebar/90 backdrop-blur-2xl">
          <SidebarHeader className="p-4 border-b border-sidebar-border/50">
            <div className="flex items-center gap-3">
              <ArcReactor size="sm" />
              <div className="flex flex-col min-w-0">
                <span className="font-mono text-sm font-bold tracking-[0.3em] jarvis-glow text-primary leading-tight">
                  TEJA AI
                </span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="status-dot" />
                  <span className="text-[9px] text-primary/40 font-mono tracking-[0.2em] uppercase">
                    Online
                  </span>
                </div>
              </div>
            </div>
          </SidebarHeader>

          {/* Capability indicators */}
          <div className="px-3 py-2 border-b border-sidebar-border/30 flex flex-wrap gap-1.5">
            <CapBadge icon={<Cpu className="w-2.5 h-2.5" />} label="Core" />
            <CapBadge icon={<Globe className="w-2.5 h-2.5" />} label="Web" />
            <CapBadge icon={<ImageIcon className="w-2.5 h-2.5" />} label="Vision" />
            <CapBadge icon={<Wifi className="w-2.5 h-2.5" />} label="Live" />
          </div>

          <SidebarContent className="py-2">
            <SidebarGroup>
              <SidebarGroupLabel className="text-[9px] uppercase tracking-[0.25em] text-primary/30 font-mono px-4 mb-1">
                Sessions
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <div className="px-3 mb-2">
                  <Button
                    onClick={createConversation}
                    variant="outline"
                    className="w-full justify-start gap-2 border-primary/15 hover:border-primary/50 text-primary/60 hover:text-primary font-mono text-xs tracking-widest jarvis-input-focus transition-all duration-300 bg-transparent"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    New Session
                  </Button>
                </div>
                <SidebarMenu>
                  {conversations.map(conv => (
                    <SidebarMenuItem key={conv.id}>
                      <SidebarMenuButton
                        isActive={conv.id === activeConversationId}
                        onClick={() => setActiveConversationId(conv.id)}
                        className={`group flex justify-between items-center font-mono text-xs py-2.5 px-3 transition-all duration-200 border-l-2 ${
                          conv.id === activeConversationId
                            ? "bg-primary/8 text-primary border-primary jarvis-glow-sm"
                            : "text-muted-foreground hover:text-foreground hover:bg-white/3 border-transparent"
                        }`}
                      >
                        <span className="truncate flex-1">{conv.title || "New Session"}</span>
                        <span
                          role="button"
                          tabIndex={0}
                          className="opacity-0 group-hover:opacity-60 hover:!opacity-100 hover:text-destructive transition-opacity ml-2 flex-shrink-0 cursor-pointer"
                          onClick={(e) => { e.stopPropagation(); deleteConversation(conv.id); }}
                          onKeyDown={(e) => { if (e.key === "Enter") { e.stopPropagation(); deleteConversation(conv.id); } }}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <div className="p-3 border-t border-sidebar-border/30 flex flex-col gap-2">
            {/* Signed-in: user profile strip */}
            {isSignedIn && user ? (
              <div className="flex items-center gap-2.5 px-2 py-2 rounded-lg bg-primary/4 border border-primary/10">
                <div className="flex-shrink-0 w-7 h-7 rounded-full overflow-hidden border border-primary/30 bg-primary/10 flex items-center justify-center">
                  {user.imageUrl ? (
                    <img src={user.imageUrl} alt="avatar" className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-3.5 h-3.5 text-primary/50" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-mono text-primary/80 truncate font-semibold">
                    {user.fullName || user.username || user.primaryEmailAddress?.emailAddress?.split("@")[0] || "User"}
                  </p>
                  <p className="text-[8px] font-mono text-primary/35 truncate">
                    {user.primaryEmailAddress?.emailAddress || ""}
                  </p>
                </div>
                <button
                  onClick={() => signOut({ redirectUrl: `${import.meta.env.BASE_URL || "/"}chat` })}
                  title="Sign out"
                  className="flex-shrink-0 w-6 h-6 rounded flex items-center justify-center text-primary/30 hover:text-destructive hover:bg-destructive/10 transition-all duration-200"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              /* Signed-out: sign-in button */
              <button
                onClick={() => navigate("/sign-in")}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg border border-primary/20 hover:border-primary/50 text-primary/45 hover:text-primary/80 transition-all duration-200 font-mono text-[9px] tracking-[0.25em] uppercase bg-primary/3 hover:bg-primary/8"
              >
                <LogIn className="w-3 h-3" />
                Sign In
              </button>
            )}

            <button
              onClick={() => navigate("/patent")}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg border border-primary/15 hover:border-primary/40 text-primary/35 hover:text-primary/70 transition-all duration-200 font-mono text-[9px] tracking-[0.25em] uppercase bg-primary/3 hover:bg-primary/8"
            >
              <Award className="w-3 h-3" />
              AI Patent Certificate
            </button>
            <p className="text-[8px] font-mono text-primary/15 tracking-[0.2em] text-center uppercase">
              TEJA AI · CLASSIFIED
            </p>
          </div>
        </Sidebar>

        {/* ══ MAIN AREA ════════════════════════════════════ */}
        <main className="flex-1 flex flex-col relative min-w-0">
          <HudCorners />

          {/* Action notification banner */}
          {lastAction && (
            <div className="flex items-center justify-center gap-2 py-2 bg-primary/8 border-b border-primary/25 text-[11px] font-mono text-primary tracking-widest">
              <ExternalLink className="w-3 h-3 flex-shrink-0" />
              <span className="font-bold">TEJA LAUNCHED:</span>
              <span className="opacity-80">{lastAction.label.toUpperCase()}</span>
              <a href={lastAction.url} target="_blank" rel="noopener noreferrer" className="underline opacity-40 hover:opacity-80 ml-1 text-[10px]">
                {lastAction.url}
              </a>
            </div>
          )}

          {/* Top status bar */}
          <div className="flex items-center justify-between px-6 py-3 border-b border-border/20 backdrop-blur-sm bg-background/30 flex-shrink-0">
            <div className="flex items-center gap-3 text-[10px] font-mono text-primary/40 tracking-[0.2em] uppercase">
              <span className="status-dot" />
              <span>Neural Link Active</span>
              <span className="text-primary/20">·</span>
              <span className="text-primary/25">First-Principles Engine</span>
            </div>
            <div className="flex items-center gap-4 text-[10px] font-mono text-primary/25 tracking-widest">
              {isStreaming && (
                <span className="text-primary/60 jarvis-glow-sm animate-pulse flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary/80 animate-pulse" />
                  {mode === "imagine" ? "Generating..." : "Reasoning..."}
                </span>
              )}
              {recordingState === "recording" && (
                <span className="text-destructive animate-pulse flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-destructive animate-pulse" />
                  Recording
                </span>
              )}
              {playbackState === "playing" && (
                <span className="text-primary/60 animate-pulse">◈ Audio</span>
              )}
              <span className="border border-primary/15 px-2 py-0.5 rounded text-[9px]">v8.0</span>
            </div>
          </div>

          {/* Chat area */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 md:px-10 py-8 scroll-smooth">
            {isIdle ? (
              <BootSequence />
            ) : (
              <div className="max-w-3xl mx-auto space-y-6 pb-4">

                {messages.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[80%] font-mono text-sm leading-relaxed px-5 py-4 ${
                      msg.role === "user" ? "msg-user text-foreground/85" : "msg-jarvis text-primary/90"
                    }`}>
                      {msg.role === "assistant" && (
                        <div className="flex items-center gap-1.5 text-[9px] text-primary/40 mb-2 tracking-[0.25em] uppercase">
                          <Zap className="w-2.5 h-2.5" /> TEJA
                        </div>
                      )}
                      <MessageContent content={msg.content} />
                    </div>
                  </div>
                ))}

                {/* Optimistic user message */}
                {optimisticMessage && optimisticMessage !== "Audio input..." && (
                  <div className="flex justify-end">
                    <div className="max-w-[80%] font-mono text-sm leading-relaxed px-5 py-4 msg-user text-foreground/40">
                      {optimisticMessage}
                    </div>
                  </div>
                )}

                {/* Streaming Teja response */}
                {streamingContent && (
                  <div className="flex justify-start">
                    <div className="max-w-[80%] font-mono text-sm leading-relaxed px-5 py-4 msg-jarvis text-primary/90">
                      <div className="flex items-center gap-1.5 text-[9px] text-primary/40 mb-2 tracking-[0.25em] uppercase">
                        <Zap className="w-2.5 h-2.5" /> TEJA
                      </div>
                      <div className="whitespace-pre-wrap leading-relaxed">
                        {streamingContent}
                        <span className="inline-block w-0.5 h-4 bg-primary/80 ml-0.5 animate-pulse align-middle" />
                      </div>
                    </div>
                  </div>
                )}

                {/* Thinking indicator */}
                {isStreaming && !streamingContent && (
                  <div className="flex justify-start"><Thinking /></div>
                )}
              </div>
            )}
          </div>

          {/* Voice status bar */}
          {(recordingState === "recording" || playbackState === "playing") && (
            <div className="flex items-center justify-center gap-3 py-2 bg-primary/5 border-t border-primary/10">
              <Waveform />
              <span className="text-[10px] font-mono text-primary/60 tracking-widest uppercase">
                {recordingState === "recording" ? "Recording — release to process" : "Audio output active"}
              </span>
              <Waveform />
            </div>
          )}

          {/* Input bar */}
          <div className="p-4 md:px-10 md:pb-6 border-t border-border/15 bg-background/60 backdrop-blur-xl flex-shrink-0">
            <div className="max-w-3xl mx-auto relative">
              <HudCorners />

              {/* Image attachment preview */}
              {attachedImage && (
                <div className="mb-3 flex items-center gap-3 px-4 py-2.5 bg-primary/5 border border-primary/20 rounded-xl">
                  <img src={attachedImage.preview} alt="Attached" className="w-10 h-10 rounded-lg object-cover border border-primary/25" />
                  <span className="text-[11px] font-mono text-primary/55 flex-1">Image attached — Teja will analyze</span>
                  <button type="button" onClick={clearAttachment} className="text-primary/30 hover:text-destructive transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Mode indicator */}
              {mode === "imagine" && (
                <div className="mb-3 flex items-center gap-2 px-4 py-2 bg-primary/5 border border-primary/20 rounded-xl">
                  <Wand2 className="w-3.5 h-3.5 text-primary/55" />
                  <span className="text-[10px] font-mono text-primary/55 flex-1 tracking-[0.2em] uppercase">Image Generation Mode</span>
                  <button type="button" onClick={() => setMode("chat")} className="text-primary/30 hover:text-destructive transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              <form
                onSubmit={onSubmit}
                className="flex items-center gap-2 px-4 py-3 bg-secondary/30 border border-border/40 rounded-2xl jarvis-input-focus transition-all duration-300"
              >
                {/* Mic button */}
                <button
                  type="button"
                  className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 ${
                    recordingState === "recording"
                      ? "bg-destructive/20 text-destructive border border-destructive/50 shadow-[0_0_12px_hsl(0_85%_60%/0.3)]"
                      : "text-primary/50 hover:text-primary hover:bg-primary/10 border border-transparent hover:border-primary/25"
                  }`}
                  onMouseDown={handleStartVoice}
                  onMouseUp={handleStopVoice}
                  onMouseLeave={recordingState === "recording" ? handleStopVoice : undefined}
                  onTouchStart={handleStartVoice}
                  onTouchEnd={handleStopVoice}
                >
                  {recordingState === "recording" ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>

                {/* Attach image button */}
                <button
                  type="button"
                  title="Attach image for Teja to analyze"
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 border ${
                    attachedImage
                      ? "bg-primary/20 text-primary border-primary/50 shadow-[0_0_10px_hsl(210_100%_65%/0.25)]"
                      : "text-primary/45 hover:text-primary hover:bg-primary/10 border-transparent hover:border-primary/25"
                  }`}
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                {/* Image generation mode button */}
                <button
                  type="button"
                  title="Generate image from description"
                  onClick={() => { setMode(m => m === "imagine" ? "chat" : "imagine"); clearAttachment(); }}
                  className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 border ${
                    mode === "imagine"
                      ? "bg-primary/20 text-primary border-primary/50 shadow-[0_0_10px_hsl(210_100%_65%/0.25)]"
                      : "text-primary/45 hover:text-primary hover:bg-primary/10 border-transparent hover:border-primary/25"
                  }`}
                >
                  <Wand2 className="w-4 h-4" />
                </button>

                {/* Text input */}
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={onKeyDown}
                  placeholder={placeholder}
                  className="flex-1 bg-transparent border-none outline-none font-mono text-sm py-2 px-2 text-foreground placeholder:text-muted-foreground/35 focus:ring-0 min-w-0"
                  disabled={recordingState === "recording" || isStreaming}
                />

                {/* Send button */}
                <button
                  type="submit"
                  disabled={(!input.trim() && !attachedImage) || isStreaming || recordingState === "recording"}
                  className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center border transition-all duration-300 disabled:opacity-25 disabled:cursor-not-allowed
                    border-primary/25 text-primary/55 hover:text-primary hover:bg-primary/15 hover:border-primary/55
                    hover:shadow-[0_0_20px_hsl(210_100%_65%/0.3)]"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

              <p className="text-center text-[9px] text-primary/15 font-mono tracking-[0.25em] mt-2 uppercase">
                Teja AI · Advanced Intelligence · Encrypted
              </p>
            </div>
          </div>
        </main>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileSelect}
      />
    </SidebarProvider>
  );
}
