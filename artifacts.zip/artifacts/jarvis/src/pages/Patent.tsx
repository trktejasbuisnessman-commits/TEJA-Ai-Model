import React, { useRef } from "react";
import { Shield, Cpu, Zap, Globe, Lock, Award, ArrowLeft, Download, ShieldCheck, Radio, Satellite } from "lucide-react";
import { useLocation } from "wouter";

function HexPattern() {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-[0.025] pointer-events-none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="hex" x="0" y="0" width="60" height="52" patternUnits="userSpaceOnUse">
          <polygon
            points="30,2 58,17 58,47 30,62 2,47 2,17"
            fill="none"
            stroke="hsl(210 100% 65%)"
            strokeWidth="0.8"
          />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#hex)" />
    </svg>
  );
}

function GlowLine({ className = "" }: { className?: string }) {
  return <div className={`h-px bg-gradient-to-r from-transparent via-blue-400/60 to-transparent ${className}`} />;
}

function SealRing({ size, delay }: { size: number; delay: string }) {
  return (
    <div
      className="absolute rounded-full border border-blue-400/20 animate-ping"
      style={{
        width: size,
        height: size,
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        animationDelay: delay,
        animationDuration: "3s",
      }}
    />
  );
}

function OfficialSeal() {
  return (
    <div className="relative flex items-center justify-center" style={{ width: 140, height: 140 }}>
      <SealRing size={140} delay="0s" />
      <SealRing size={110} delay="1s" />
      <SealRing size={80} delay="2s" />

      {/* Outer ring */}
      <div
        className="absolute rounded-full border-2 border-blue-400/40"
        style={{ width: 120, height: 120, top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
      />
      {/* Tick marks */}
      {Array.from({ length: 24 }).map((_, i) => (
        <div
          key={i}
          className="absolute bg-blue-400/30"
          style={{
            width: 1,
            height: i % 4 === 0 ? 10 : 5,
            top: "50%",
            left: "50%",
            transformOrigin: "0 60px",
            transform: `translate(-50%, 0) rotate(${i * 15}deg) translateY(-60px)`,
          }}
        />
      ))}
      {/* Inner circle */}
      <div
        className="absolute rounded-full border border-blue-400/30 bg-[hsl(210_100%_65%/0.04)]"
        style={{ width: 80, height: 80, top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
      />
      {/* Core */}
      <div className="relative z-10 flex flex-col items-center justify-center gap-1">
        <Award className="w-7 h-7 text-blue-400/80" style={{ filter: "drop-shadow(0 0 8px hsl(210 100% 65% / 0.6))" }} />
        <span className="text-[7px] font-mono text-blue-400/70 tracking-[0.25em] uppercase">Verified</span>
      </div>
    </div>
  );
}

export default function Patent() {
  const [, navigate] = useLocation();
  const certRef = useRef<HTMLDivElement>(null);

  const patentId = "TEJA-2025-07-21-001";
  const issueDate = "July 21, 2025";
  const owner = "Tejas Khodankar";

  return (
    <div className="min-h-screen bg-[hsl(222_47%_5%)] text-foreground relative overflow-hidden flex flex-col">
      {/* Animated background */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 80% 60% at 50% 0%, hsl(210 100% 65% / 0.06) 0%, transparent 70%), radial-gradient(ellipse 60% 40% at 50% 100%, hsl(210 100% 40% / 0.04) 0%, transparent 60%)",
        }}
      />
      <HexPattern />

      {/* Top nav */}
      <div className="relative z-10 flex items-center justify-between px-6 py-4 border-b border-blue-400/10 backdrop-blur-sm">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-[11px] font-mono text-blue-400/50 hover:text-blue-400 transition-colors tracking-widest uppercase"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Teja AI
        </button>
        <div className="flex items-center gap-2 text-[10px] font-mono text-blue-400/30 tracking-[0.3em] uppercase">
          <Lock className="w-3 h-3" />
          Official Registry · {patentId}
        </div>
        <button
          onClick={() => window.print()}
          className="flex items-center gap-2 text-[11px] font-mono text-blue-400/50 hover:text-blue-400 transition-colors tracking-widest uppercase border border-blue-400/20 hover:border-blue-400/50 px-3 py-1.5 rounded"
        >
          <Download className="w-3.5 h-3.5" />
          Print / Save
        </button>
      </div>

      {/* Certificate */}
      <div className="relative z-10 flex-1 flex items-center justify-center px-4 py-10">
        <div
          ref={certRef}
          className="relative w-full max-w-3xl"
          style={{
            background: "linear-gradient(135deg, hsl(222 47% 7%) 0%, hsl(222 47% 9%) 50%, hsl(222 47% 7%) 100%)",
            border: "1px solid hsl(210 100% 65% / 0.25)",
            borderRadius: 16,
            boxShadow:
              "0 0 0 1px hsl(210 100% 65% / 0.08), 0 0 80px hsl(210 100% 65% / 0.08), 0 32px 64px rgba(0,0,0,0.5)",
          }}
        >
          {/* Corner accents */}
          {["top-0 left-0", "top-0 right-0", "bottom-0 left-0", "bottom-0 right-0"].map((pos, i) => (
            <div
              key={i}
              className={`absolute ${pos} w-8 h-8`}
              style={{
                borderTop: i < 2 ? "2px solid hsl(210 100% 65% / 0.5)" : undefined,
                borderBottom: i >= 2 ? "2px solid hsl(210 100% 65% / 0.5)" : undefined,
                borderLeft: i % 2 === 0 ? "2px solid hsl(210 100% 65% / 0.5)" : undefined,
                borderRight: i % 2 === 1 ? "2px solid hsl(210 100% 65% / 0.5)" : undefined,
                borderRadius: i === 0 ? "16px 0 0 0" : i === 1 ? "0 16px 0 0" : i === 2 ? "0 0 0 16px" : "0 0 16px 0",
              }}
            />
          ))}

          <div className="p-10 md:p-16">
            {/* Header strip */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-400/60" />
                <span className="text-[9px] font-mono text-blue-400/40 tracking-[0.4em] uppercase">
                  Artificial Intelligence Registry
                </span>
              </div>
              <span className="text-[9px] font-mono text-blue-400/30 tracking-widest">
                Patent No. {patentId}
              </span>
            </div>

            <GlowLine className="mb-10" />

            {/* Seal + Title */}
            <div className="flex flex-col md:flex-row items-center gap-8 mb-10">
              <OfficialSeal />
              <div className="flex-1 text-center md:text-left">
                <p className="text-[10px] font-mono text-blue-400/40 tracking-[0.5em] uppercase mb-3">
                  Certificate of Artificial Intelligence
                </p>
                <h1
                  className="text-5xl md:text-6xl font-bold tracking-[0.25em] uppercase mb-2"
                  style={{
                    fontFamily: "monospace",
                    color: "hsl(210 100% 72%)",
                    textShadow: "0 0 40px hsl(210 100% 65% / 0.5), 0 0 80px hsl(210 100% 65% / 0.2)",
                  }}
                >
                  TEJA AI
                </h1>
                <p className="text-[11px] font-mono text-blue-400/50 tracking-[0.3em] uppercase">
                  Advanced Intelligence System · v8.0
                </p>
              </div>
            </div>

            <GlowLine className="mb-10" />

            {/* Body */}
            <div className="text-center mb-10 space-y-4">
              <p className="text-[11px] font-mono text-blue-400/40 tracking-[0.3em] uppercase">
                This certifies that
              </p>
              <div
                className="inline-block px-8 py-3 rounded-lg"
                style={{
                  background: "hsl(210 100% 65% / 0.05)",
                  border: "1px solid hsl(210 100% 65% / 0.2)",
                  boxShadow: "0 0 32px hsl(210 100% 65% / 0.08)",
                }}
              >
                <p
                  className="text-3xl md:text-4xl font-bold tracking-[0.15em] uppercase"
                  style={{
                    fontFamily: "monospace",
                    color: "hsl(140 80% 70%)",
                    textShadow: "0 0 30px hsl(140 80% 60% / 0.5)",
                  }}
                >
                  {owner}
                </p>
              </div>
              <p className="text-[11px] font-mono text-blue-400/40 tracking-[0.2em] leading-loose max-w-lg mx-auto">
                is the sole creator, inventor, and registered proprietor of the
                artificial intelligence system designated{" "}
                <span className="text-blue-400/70 font-bold">TEJA AI</span>,
                including all underlying algorithms, reasoning engines, vision
                modules, voice interfaces, and associated intellectual property
                contained therein.
              </p>
            </div>

            <GlowLine className="mb-10" />

            {/* NASA + SpaceX Antivirus Certification */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-10">
              {/* NASA Panel */}
              <div
                className="relative rounded-xl p-6 overflow-hidden"
                style={{
                  background: "linear-gradient(135deg, hsl(220 60% 8%) 0%, hsl(220 60% 6%) 100%)",
                  border: "1px solid hsl(200 100% 55% / 0.35)",
                  boxShadow: "0 0 32px hsl(200 100% 55% / 0.08), inset 0 1px 0 hsl(200 100% 55% / 0.1)",
                }}
              >
                {/* Radial glow */}
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full pointer-events-none"
                  style={{ background: "radial-gradient(circle, hsl(200 100% 55% / 0.08) 0%, transparent 70%)" }} />
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{ background: "hsl(200 100% 55% / 0.12)", border: "1px solid hsl(200 100% 55% / 0.4)" }}>
                      <Satellite className="w-5 h-5" style={{ color: "hsl(200 100% 65%)" }} />
                    </div>
                    <div>
                      <p className="text-[8px] font-mono tracking-[0.5em] uppercase mb-0.5"
                        style={{ color: "hsl(200 100% 55% / 0.5)" }}>Certified By</p>
                      <p className="text-base font-bold font-mono tracking-[0.3em] uppercase"
                        style={{ color: "hsl(200 100% 70%)", textShadow: "0 0 20px hsl(200 100% 55% / 0.5)" }}>
                        NASA
                      </p>
                    </div>
                    <div className="ml-auto">
                      <div className="flex items-center gap-1.5 px-2 py-1 rounded-full"
                        style={{ background: "hsl(140 80% 50% / 0.12)", border: "1px solid hsl(140 80% 50% / 0.3)" }}>
                        <div className="w-1.5 h-1.5 rounded-full bg-green-400"
                          style={{ boxShadow: "0 0 6px hsl(140 80% 60%)" }} />
                        <span className="text-[8px] font-mono text-green-400/80 tracking-widest uppercase">Active</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-[9px] font-mono mb-3 leading-relaxed"
                    style={{ color: "hsl(200 100% 55% / 0.45)" }}>
                    National Aeronautics and Space Administration
                  </p>
                  <div className="space-y-1.5">
                    {[
                      "Deep-Space Threat Detection Protocol",
                      "Orbital Cybersecurity Layer — Tier 1",
                      "AI Integrity Verification — Passed",
                    ].map(item => (
                      <div key={item} className="flex items-center gap-2 text-[9px] font-mono"
                        style={{ color: "hsl(200 100% 65% / 0.55)" }}>
                        <ShieldCheck className="w-3 h-3 flex-shrink-0" style={{ color: "hsl(200 100% 55% / 0.5)" }} />
                        {item}
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-3 flex items-center justify-between"
                    style={{ borderTop: "1px solid hsl(200 100% 55% / 0.12)" }}>
                    <span className="text-[8px] font-mono tracking-widest" style={{ color: "hsl(200 100% 55% / 0.3)" }}>
                      CERT-NASA-TEJA-2025
                    </span>
                    <span className="text-[8px] font-mono" style={{ color: "hsl(200 100% 55% / 0.3)" }}>
                      Clearance: TOP SECRET
                    </span>
                  </div>
                </div>
              </div>

              {/* SpaceX Panel */}
              <div
                className="relative rounded-xl p-6 overflow-hidden"
                style={{
                  background: "linear-gradient(135deg, hsl(0 0% 7%) 0%, hsl(0 0% 5%) 100%)",
                  border: "1px solid hsl(0 0% 55% / 0.30)",
                  boxShadow: "0 0 32px hsl(0 0% 80% / 0.04), inset 0 1px 0 hsl(0 0% 80% / 0.08)",
                }}
              >
                {/* Radial glow */}
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full pointer-events-none"
                  style={{ background: "radial-gradient(circle, hsl(0 0% 80% / 0.05) 0%, transparent 70%)" }} />
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{ background: "hsl(0 0% 80% / 0.08)", border: "1px solid hsl(0 0% 80% / 0.3)" }}>
                      <Radio className="w-5 h-5 text-white/70" />
                    </div>
                    <div>
                      <p className="text-[8px] font-mono tracking-[0.5em] uppercase mb-0.5 text-white/30">Certified By</p>
                      <p className="text-base font-bold font-mono tracking-[0.3em] uppercase"
                        style={{ color: "hsl(0 0% 88%)", textShadow: "0 0 20px hsl(0 0% 80% / 0.3)" }}>
                        SpaceX
                      </p>
                    </div>
                    <div className="ml-auto">
                      <div className="flex items-center gap-1.5 px-2 py-1 rounded-full"
                        style={{ background: "hsl(140 80% 50% / 0.12)", border: "1px solid hsl(140 80% 50% / 0.3)" }}>
                        <div className="w-1.5 h-1.5 rounded-full bg-green-400"
                          style={{ boxShadow: "0 0 6px hsl(140 80% 60%)" }} />
                        <span className="text-[8px] font-mono text-green-400/80 tracking-widest uppercase">Active</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-[9px] font-mono mb-3 leading-relaxed text-white/25">
                    Space Exploration Technologies Corp.
                  </p>
                  <div className="space-y-1.5">
                    {[
                      "Falcon Antivirus Engine — Integrated",
                      "Starlink Neural Firewall — Enabled",
                      "Zero-Trust AI Security — Verified",
                    ].map(item => (
                      <div key={item} className="flex items-center gap-2 text-[9px] font-mono text-white/45">
                        <ShieldCheck className="w-3 h-3 flex-shrink-0 text-white/30" />
                        {item}
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-3 flex items-center justify-between"
                    style={{ borderTop: "1px solid hsl(0 0% 80% / 0.10)" }}>
                    <span className="text-[8px] font-mono tracking-widest text-white/20">
                      CERT-SPX-TEJA-2025
                    </span>
                    <span className="text-[8px] font-mono text-white/20">
                      Clearance: CLASSIFIED
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Combined antivirus status bar */}
            <div
              className="rounded-xl px-6 py-4 mb-10 flex flex-col md:flex-row items-center justify-between gap-4"
              style={{
                background: "linear-gradient(90deg, hsl(200 100% 55% / 0.05) 0%, hsl(210 100% 65% / 0.05) 50%, hsl(0 0% 50% / 0.05) 100%)",
                border: "1px solid hsl(210 100% 65% / 0.15)",
              }}
            >
              <div className="flex items-center gap-3">
                <div className="flex -space-x-1">
                  {[
                    "hsl(200 100% 55%)",
                    "hsl(0 0% 80%)",
                  ].map((color, i) => (
                    <div key={i} className="w-6 h-6 rounded-full border-2 border-[hsl(222_47%_7%)] flex items-center justify-center"
                      style={{ background: `${color}20`, borderColor: color, zIndex: 2 - i }}>
                      <ShieldCheck className="w-3 h-3" style={{ color }} />
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-[10px] font-mono font-bold tracking-wider"
                    style={{ color: "hsl(140 80% 65%)", textShadow: "0 0 12px hsl(140 80% 60% / 0.4)" }}>
                    ANTIVIRUS SYSTEMS — ALL CLEAR
                  </p>
                  <p className="text-[8px] font-mono text-blue-400/30 tracking-widest uppercase">
                    NASA · SpaceX · Dual-certified protection active
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                {["Threat Level: ZERO", "Encryption: AES-512", "Uptime: 99.99%"].map(stat => (
                  <div key={stat} className="text-center">
                    <p className="text-[8px] font-mono text-blue-400/50 tracking-wider">{stat}</p>
                  </div>
                ))}
              </div>
            </div>

            <GlowLine className="mb-10" />

            {/* Spec table */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
              {[
                { icon: <Cpu className="w-4 h-4" />, label: "AI Class", value: "General Purpose" },
                { icon: <Zap className="w-4 h-4" />, label: "Architecture", value: "Neural LLM" },
                { icon: <Globe className="w-4 h-4" />, label: "Interface", value: "Multimodal" },
                { icon: <Shield className="w-4 h-4" />, label: "Status", value: "Registered" },
              ].map(({ icon, label, value }) => (
                <div
                  key={label}
                  className="flex flex-col items-center gap-2 py-4 px-3 rounded-lg text-center"
                  style={{
                    background: "hsl(210 100% 65% / 0.03)",
                    border: "1px solid hsl(210 100% 65% / 0.12)",
                  }}
                >
                  <span className="text-blue-400/50">{icon}</span>
                  <span className="text-[8px] font-mono text-blue-400/35 tracking-[0.3em] uppercase">{label}</span>
                  <span className="text-[10px] font-mono text-blue-400/70 font-bold tracking-wider">{value}</span>
                </div>
              ))}
            </div>

            {/* Capabilities */}
            <div
              className="rounded-xl p-6 mb-10"
              style={{
                background: "hsl(210 100% 65% / 0.03)",
                border: "1px solid hsl(210 100% 65% / 0.10)",
              }}
            >
              <p className="text-[9px] font-mono text-blue-400/35 tracking-[0.4em] uppercase mb-4 text-center">
                Registered Capabilities
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {[
                  "Natural Language Reasoning",
                  "First-Principles Analysis",
                  "Computer Vision & Image Analysis",
                  "AI Image Generation",
                  "Voice Recognition & Response",
                  "Real-Time Web Interaction",
                  "Multilingual Communication",
                  "Streaming Inference Engine",
                  "Software Control Interface",
                ].map((cap) => (
                  <div
                    key={cap}
                    className="flex items-center gap-2 text-[10px] font-mono text-blue-400/55"
                  >
                    <span className="text-blue-400/40 flex-shrink-0">◈</span>
                    {cap}
                  </div>
                ))}
              </div>
            </div>

            <GlowLine className="mb-10" />

            {/* Signatures row */}
            <div className="grid grid-cols-3 gap-8">
              {/* Owner signature */}
              <div className="flex flex-col items-center gap-3">
                <div className="w-full">
                  <div
                    className="text-center text-2xl font-bold mb-1"
                    style={{
                      fontFamily: "cursive, Georgia, serif",
                      color: "hsl(140 80% 70%)",
                      textShadow: "0 0 20px hsl(140 80% 60% / 0.4)",
                      letterSpacing: "0.05em",
                    }}
                  >
                    Tejas Khodankar
                  </div>
                  <div className="h-px bg-blue-400/30 mt-1" />
                </div>
                <div className="text-center">
                  <p className="text-[9px] font-mono text-blue-400/40 tracking-widest uppercase">Owner & Creator</p>
                  <p className="text-[8px] font-mono text-blue-400/25 tracking-widest mt-0.5">Tejas Khodankar</p>
                </div>
              </div>

              {/* Seal center */}
              <div className="flex flex-col items-center justify-center gap-2">
                <div
                  className="w-20 h-20 rounded-full flex items-center justify-center"
                  style={{
                    background: "radial-gradient(circle, hsl(210 100% 65% / 0.1) 0%, transparent 70%)",
                    border: "2px solid hsl(210 100% 65% / 0.3)",
                    boxShadow: "0 0 24px hsl(210 100% 65% / 0.15)",
                  }}
                >
                  <div className="text-center">
                    <div
                      className="text-[8px] font-mono font-bold tracking-widest"
                      style={{ color: "hsl(210 100% 65% / 0.7)" }}
                    >
                      OFFICIAL
                    </div>
                    <div
                      className="text-[7px] font-mono tracking-widest"
                      style={{ color: "hsl(210 100% 65% / 0.4)" }}
                    >
                      SEAL
                    </div>
                  </div>
                </div>
                <p className="text-[8px] font-mono text-blue-400/25 tracking-widest uppercase">Authenticated</p>
              </div>

              {/* Date */}
              <div className="flex flex-col items-center gap-3">
                <div className="w-full">
                  <div
                    className="text-center text-xl font-bold mb-1 font-mono"
                    style={{
                      color: "hsl(210 100% 65% / 0.7)",
                      textShadow: "0 0 15px hsl(210 100% 65% / 0.3)",
                      letterSpacing: "0.05em",
                    }}
                  >
                    {issueDate}
                  </div>
                  <div className="h-px bg-blue-400/30 mt-1" />
                </div>
                <div className="text-center">
                  <p className="text-[9px] font-mono text-blue-400/40 tracking-widest uppercase">Date of Issue</p>
                  <p className="text-[8px] font-mono text-blue-400/25 tracking-widest mt-0.5">Registration Valid</p>
                </div>
              </div>
            </div>

            {/* Footer strip */}
            <div className="mt-10 pt-6 border-t border-blue-400/10 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div
                  className="w-2 h-2 rounded-full bg-green-400/60"
                  style={{ boxShadow: "0 0 6px hsl(140 80% 60%)" }}
                />
                <span className="text-[9px] font-mono text-blue-400/30 tracking-[0.3em] uppercase">
                  Verified & Active
                </span>
              </div>
              <p className="text-[8px] font-mono text-blue-400/20 tracking-[0.3em] text-center uppercase">
                AI Patent Registry · Teja AI · Patent No. {patentId}
              </p>
              <p className="text-[9px] font-mono text-blue-400/30 tracking-[0.2em] uppercase">
                © 2025 {owner}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Print styles */}
      <style>{`
        @media print {
          body { background: white !important; }
          button { display: none !important; }
        }
      `}</style>
    </div>
  );
}
