import { useState } from "react";
import { useClerk } from "@clerk/react";
import { useSignIn } from "@clerk/react/legacy";
import { useLocation } from "wouter";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

/* ── shared background ───────────────────────────────────────── */
function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="flex min-h-screen items-center justify-center relative overflow-hidden"
      style={{ background: "hsl(222 47% 5%)" }}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 60% at 50% 40%, hsl(210 100% 65% / 0.07) 0%, transparent 70%)",
        }}
      />
      <svg className="absolute inset-0 w-full h-full opacity-[0.025] pointer-events-none">
        <defs>
          <pattern id="si-hex" x="0" y="0" width="60" height="52" patternUnits="userSpaceOnUse">
            <polygon
              points="30,2 58,17 58,47 30,62 2,47 2,17"
              fill="none"
              stroke="hsl(210 100% 65%)"
              strokeWidth="0.8"
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#si-hex)" />
      </svg>
      {children}
    </div>
  );
}

/* ── Google button ───────────────────────────────────────────── */
function GoogleBtn({ label, onClick, loading, disabled }: { label: string; onClick: () => void; loading: boolean; disabled?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={loading || disabled}
      className="w-full flex items-center justify-center gap-3 py-3 px-5 rounded-xl font-mono text-xs tracking-widest uppercase transition-all duration-200 disabled:opacity-50"
      style={{
        background: "linear-gradient(135deg, hsl(210 100% 38% / 0.85), hsl(225 100% 32% / 0.85))",
        border: "1px solid hsl(210 100% 60% / 0.3)",
        boxShadow: "0 0 28px hsl(210 100% 60% / 0.2)",
        color: "#e0eeff",
      }}
    >
      {loading ? (
        <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" opacity="0.25" />
          <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      ) : (
        <svg viewBox="0 0 24 24" className="w-4 h-4 flex-shrink-0">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05" />
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
        </svg>
      )}
      {loading ? "Redirecting…" : label}
    </button>
  );
}

/* ── input ───────────────────────────────────────────────────── */
function Field({
  label, type = "text", value, onChange, placeholder, disabled, autoComplete, inputMode, maxLength,
}: {
  label: string; type?: string; value: string;
  onChange: (v: string) => void; placeholder?: string; disabled?: boolean;
  autoComplete?: string; inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"]; maxLength?: number;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[9px] font-mono tracking-[0.3em] uppercase text-blue-300/50">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        autoComplete={autoComplete}
        inputMode={inputMode}
        maxLength={maxLength}
        className="w-full rounded-lg px-4 py-2.5 font-mono text-sm bg-transparent border outline-none transition-all duration-200 text-blue-100 placeholder-blue-400/20 disabled:opacity-40"
        style={{ borderColor: "hsl(210 100% 60% / 0.2)" }}
        onFocus={(e) => (e.currentTarget.style.borderColor = "hsl(210 100% 60% / 0.55)")}
        onBlur={(e) => (e.currentTarget.style.borderColor = "hsl(210 100% 60% / 0.2)")}
      />
    </div>
  );
}

/* ── primary button ──────────────────────────────────────────── */
function PrimaryBtn({ children, loading, disabled }: { children: React.ReactNode; loading?: boolean; disabled?: boolean }) {
  return (
    <button
      type="submit"
      disabled={loading || disabled}
      className="w-full py-3 rounded-xl font-mono text-xs tracking-widest uppercase transition-all duration-200 disabled:opacity-40"
      style={{
        background: "hsl(210 100% 50%)",
        boxShadow: "0 0 20px hsl(210 100% 60% / 0.3)",
        color: "#fff",
      }}
    >
      {loading ? "Please wait…" : children}
    </button>
  );
}

/* ── divider ─────────────────────────────────────────────────── */
function Divider() {
  return (
    <div className="flex items-center gap-3">
      <div className="flex-1 h-px" style={{ background: "hsl(210 100% 60% / 0.12)" }} />
      <span className="text-[9px] font-mono tracking-[0.3em] text-blue-400/25 uppercase">or</span>
      <div className="flex-1 h-px" style={{ background: "hsl(210 100% 60% / 0.12)" }} />
    </div>
  );
}

/* ── card ────────────────────────────────────────────────────── */
function Card({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="rounded-2xl w-full max-w-[420px] p-8 flex flex-col gap-6"
      style={{
        background: "hsl(222 40% 9%)",
        border: "1px solid hsl(210 100% 60% / 0.1)",
        boxShadow: "0 0 80px hsl(210 100% 60% / 0.08), 0 32px 64px rgba(0,0,0,0.5)",
      }}
    >
      {children}
    </div>
  );
}

/* ── main sign-in page ───────────────────────────────────────── */
export default function SignInPage() {
  const { signIn, isLoaded } = useSignIn();
  const { setActive } = useClerk();
  const [, navigate] = useLocation();

  const [step, setStep] = useState<"start" | "otp">("start");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState("");

  /* Google OAuth — no Turnstile */
  async function handleGoogle() {
    if (!isLoaded || !signIn) {
      setError("Authentication is still loading. Please try again in a moment.");
      return;
    }
    setGoogleLoading(true);
    setError("");
    try {
      await signIn!.authenticateWithRedirect({
        strategy: "oauth_google",
        redirectUrl: `${window.location.origin}${basePath}/sign-in/sso-callback`,
        redirectUrlComplete: `${window.location.origin}${basePath}/chat`,
      });
    } catch (e: any) {
      setError(e?.errors?.[0]?.message ?? "Google sign-in failed. Try again.");
      setGoogleLoading(false);
    }
  }

  /* Email OTP — step 1: send code */
  async function handleSendCode(e: React.FormEvent) {
    e.preventDefault();
    if (!isLoaded || !signIn) {
      setError("Authentication is still loading. Please try again in a moment.");
      return;
    }
    if (!email.trim()) {
      setError("Enter your email address to continue.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await signIn!.create({ strategy: "email_code", identifier: email.trim() });
      setStep("otp");
    } catch (e: any) {
      setError(e?.errors?.[0]?.message ?? "Could not send code. Check the email address.");
    } finally {
      setLoading(false);
    }
  }

  /* Email OTP — step 2: verify code */
  async function handleVerifyCode(e: React.FormEvent) {
    e.preventDefault();
    if (!isLoaded || !signIn) {
      setError("Authentication is still loading. Please try again in a moment.");
      return;
    }
    if (!otp.trim()) {
      setError("Enter the verification code from your email.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result = await signIn!.attemptFirstFactor({ strategy: "email_code", code: otp.trim() });
      if (result.status === "complete") {
        await setActive({ session: result.createdSessionId });
        navigate("/chat");
      } else {
        setError("Verification incomplete. Please try again.");
      }
    } catch (e: any) {
      setError(e?.errors?.[0]?.message ?? "Invalid code. Try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell>
      <div className="relative z-10 w-full px-4 flex flex-col items-center gap-6">
        {/* Logo */}
        <img
          src={`${basePath}/logo.svg`}
          alt="Teja AI"
          className="w-12 h-12"
          style={{ filter: "drop-shadow(0 0 14px hsl(210 100% 60% / 0.5))" }}
        />

        <Card>
          {/* Header */}
          <div className="text-center flex flex-col gap-1">
            <h1 className="font-mono text-lg font-bold tracking-[0.3em] uppercase text-blue-100"
              style={{ textShadow: "0 0 30px hsl(210 100% 60% / 0.3)" }}>
              {step === "otp" ? "Check your email" : "Welcome back"}
            </h1>
            <p className="text-[10px] font-mono text-blue-400/40 tracking-wider">
              {step === "otp"
                ? `Code sent to ${email}`
                : "Sign in to access Teja AI"}
            </p>
          </div>

          {step === "start" ? (
            <>
              {/* Google */}
               <GoogleBtn label="Continue with Google" onClick={handleGoogle} loading={googleLoading} disabled={!isLoaded} />

              <Divider />

              {/* Email OTP */}
              <form onSubmit={handleSendCode} className="flex flex-col gap-4">
                <Field
                  label="Email address"
                  type="email"
                  value={email}
                  onChange={setEmail}
                  placeholder="you@example.com"
                  disabled={loading}
                  autoComplete="email"
                />
                {error && (
                  <p className="text-[10px] font-mono text-red-400/80 text-center">{error}</p>
                )}
               <PrimaryBtn loading={loading} disabled={!isLoaded}>Continue with email →</PrimaryBtn>
              </form>
            </>
          ) : (
            /* OTP step */
            <form onSubmit={handleVerifyCode} className="flex flex-col gap-4">
              <Field
                label="6-digit code"
                type="text"
                value={otp}
                onChange={setOtp}
                placeholder="123456"
                disabled={loading}
                autoComplete="one-time-code"
                inputMode="numeric"
                maxLength={6}
              />
              {error && (
                <p className="text-[10px] font-mono text-red-400/80 text-center">{error}</p>
              )}
              <PrimaryBtn loading={loading}>Verify &amp; sign in →</PrimaryBtn>
              <button
                type="button"
                onClick={() => { setStep("start"); setOtp(""); setError(""); }}
                className="text-[9px] font-mono text-blue-400/30 hover:text-blue-400/60 tracking-widest uppercase text-center transition-colors"
              >
                ← Use a different email
              </button>
            </form>
          )}

          {/* Footer */}
          <p className="text-center text-[9px] font-mono text-blue-400/25 tracking-wider">
            No account?{" "}
            <button
              type="button"
              onClick={() => navigate("/sign-up")}
              className="text-blue-400/50 hover:text-blue-300/70 underline underline-offset-2 transition-colors"
            >
              Create one
            </button>
          </p>
        </Card>

        <p className="text-[9px] font-mono text-blue-400/15 tracking-[0.3em] uppercase">
          TEJA AI · Neural Access Portal · v8.0
        </p>
      </div>
    </AuthShell>
  );
}
