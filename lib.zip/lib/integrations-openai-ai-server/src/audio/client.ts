import OpenAI, { toFile } from "openai";
import { Buffer } from "node:buffer";
import { spawn } from "child_process";
import { writeFile, unlink, readFile } from "fs/promises";
import { randomUUID } from "crypto";
import { tmpdir } from "os";
import { join } from "path";

if (!process.env.GROQ_API_KEY) {
  throw new Error(
    "GROQ_API_KEY must be set. Get a free key at console.groq.com",
  );
}

export const openai = new OpenAI({
  apiKey: process.env.GROQ_API_KEY,
  baseURL: "https://api.groq.com/openai/v1",
});

export type AudioFormat = "wav" | "mp3" | "webm" | "mp4" | "ogg" | "unknown";

export function detectAudioFormat(buffer: Buffer): AudioFormat {
  if (buffer.length < 12) return "unknown";
  if (buffer[0] === 0x52 && buffer[1] === 0x49 && buffer[2] === 0x46 && buffer[3] === 0x46) return "wav";
  if (buffer[0] === 0x1a && buffer[1] === 0x45 && buffer[2] === 0xdf && buffer[3] === 0xa3) return "webm";
  if (
    (buffer[0] === 0xff && (buffer[1] === 0xfb || buffer[1] === 0xfa || buffer[1] === 0xf3)) ||
    (buffer[0] === 0x49 && buffer[1] === 0x44 && buffer[2] === 0x33)
  ) return "mp3";
  if (buffer[4] === 0x66 && buffer[5] === 0x74 && buffer[6] === 0x79 && buffer[7] === 0x70) return "mp4";
  if (buffer[0] === 0x4f && buffer[1] === 0x67 && buffer[2] === 0x67 && buffer[3] === 0x53) return "ogg";
  return "unknown";
}

export async function convertToWav(audioBuffer: Buffer): Promise<Buffer> {
  const inputPath = join(tmpdir(), `input-${randomUUID()}`);
  const outputPath = join(tmpdir(), `output-${randomUUID()}.wav`);
  try {
    await writeFile(inputPath, audioBuffer);
    await new Promise<void>((resolve, reject) => {
      const ffmpeg = spawn("ffmpeg", [
        "-i", inputPath, "-vn", "-f", "wav",
        "-ar", "16000", "-ac", "1", "-acodec", "pcm_s16le", "-y", outputPath,
      ]);
      ffmpeg.stderr.on("data", () => {});
      ffmpeg.on("close", (code) => { if (code === 0) resolve(); else reject(new Error(`ffmpeg exited with code ${code}`)); });
      ffmpeg.on("error", reject);
    });
    return await readFile(outputPath);
  } finally {
    await unlink(inputPath).catch(() => {});
    await unlink(outputPath).catch(() => {});
  }
}

export async function ensureCompatibleFormat(
  audioBuffer: Buffer
): Promise<{ buffer: Buffer; format: "wav" | "mp3" }> {
  const detected = detectAudioFormat(audioBuffer);
  if (detected === "wav") return { buffer: audioBuffer, format: "wav" };
  if (detected === "mp3") return { buffer: audioBuffer, format: "mp3" };
  const wavBuffer = await convertToWav(audioBuffer);
  return { buffer: wavBuffer, format: "wav" };
}

/** Speech-to-Text using Groq Whisper (free). */
export async function speechToText(
  audioBuffer: Buffer,
  format: "wav" | "mp3" | "webm" = "wav"
): Promise<string> {
  const file = await toFile(audioBuffer, `audio.${format}`);
  const response = await openai.audio.transcriptions.create({
    file,
    model: "whisper-large-v3",
  });
  return response.text;
}

/** Streaming Speech-to-Text (returns full text, Groq streams internally). */
export async function speechToTextStream(
  audioBuffer: Buffer,
  format: "wav" | "mp3" | "webm" = "wav"
): Promise<AsyncIterable<string>> {
  const text = await speechToText(audioBuffer, format);
  return (async function* () { yield text; })();
}

/** Text-to-Speech — not supported on Groq free tier. */
export async function textToSpeech(): Promise<Buffer> {
  throw new Error("Text-to-speech is not available on the free Groq tier.");
}

/** Streaming Text-to-Speech — not supported on Groq free tier. */
export async function textToSpeechStream(): Promise<AsyncIterable<string>> {
  throw new Error("Text-to-speech streaming is not available on the free Groq tier.");
}

/** Voice chat: transcribe audio → text reply via Groq Llama. */
export async function voiceChat(
  audioBuffer: Buffer,
  _voice = "alloy",
  inputFormat: "wav" | "mp3" = "wav"
): Promise<{ transcript: string; audioResponse: Buffer }> {
  const userText = await speechToText(audioBuffer, inputFormat);
  const chat = await openai.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    messages: [
      {
        role: "system",
        content: "You are J.A.R.V.I.S. — Just A Rather Very Intelligent System — Tony Stark's AI. Be concise, intelligent, and slightly witty.",
      },
      { role: "user", content: userText },
    ],
  });
  const replyText = chat.choices[0]?.message?.content ?? "";
  return { transcript: replyText, audioResponse: Buffer.alloc(0) };
}

/** Streaming voice chat: transcribe → stream text reply via Groq Llama. */
export async function voiceChatStream(
  audioBuffer: Buffer,
  _voice = "alloy",
  inputFormat: "wav" | "mp3" = "wav"
): Promise<AsyncIterable<{ type: "user_transcript" | "transcript" | "audio"; data: string }>> {
  const userText = await speechToText(audioBuffer, inputFormat);

  const stream = await openai.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    messages: [
      {
        role: "system",
        content: "You are J.A.R.V.I.S. — Just A Rather Very Intelligent System — Tony Stark's AI. Be concise, intelligent, and slightly witty.",
      },
      { role: "user", content: userText },
    ],
    stream: true,
  });

  return (async function* () {
    yield { type: "user_transcript" as const, data: userText };
    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) yield { type: "transcript" as const, data: content };
    }
  })();
}
